package com.example.studygroupfind;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public final class ChatActivity extends AppCompatActivity {

    private ChannelActivity binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

    }
}

