package com.example.studygroupfind;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import io.getstream.chat.android.ui.channel.list.ChannelListView;

public class ChannelActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_channel);
    }
}
